# JC VARIEDADES - PDV

Sistema inicial de ponto de venda com Next.js e Supabase.

## Configuração local
1. Instale Node.js 20 ou superior.
2. Execute `npm install`.
3. Copie `.env.example` para `.env.local`.
4. Preencha `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
5. Execute `npm run dev`.

## Publicação
Importe este repositório na Vercel e configure as mesmas variáveis em Project Settings > Environment Variables.

## Observações
- O login usa Supabase Auth com e-mail e senha.
- As tabelas esperadas são `produtos`, `clientes`, `vendas`, `itens_venda`, `caixas` e `movimentos_caixa`.
- Antes de usar em produção, implemente transações atômicas para finalizar vendas e revisar os controles de caixa.
- Não coloque chaves secretas/service_role em variáveis `NEXT_PUBLIC_`.

import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "JC VARIEDADES | PDV",
  description: "Sistema de vendas e controle da JC VARIEDADES"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
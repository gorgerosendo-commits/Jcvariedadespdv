 "use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/utils/supabase/client";
import { BarChart3, Boxes, LogOut, PackagePlus, Search, ShoppingCart, Users, Wallet } from "lucide-react";

type Product = { id: string; nome: string; codigo_barras: string | null; categoria: string | null; preco: number; estoque: number; estoque_minimo: number };
type Client = { id: string; nome: string };
type CartItem = { product: Product; quantity: number };

const money = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export default function Home() {
  const supabase = useMemo(() => createClient(), []);
  const [session, setSession] = useState<any>(null);
  const [email, setEmail] = useState("Gorgerosendo@gmail.com");
  const [password, setPassword] = useState("");
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("vendas");
  const [notice, setNotice] = useState("");
  const [cashOpen, setCashOpen] = useState<any>(null);
  const [opening, setOpening] = useState("0");
  const [newName, setNewName] = useState("");
  const [newCode, setNewCode] = useState("");
  const [newPrice, setNewPrice] = useState("");
  const [newStock, setNewStock] = useState("0");
  const [customerName, setCustomerName] = useState("");
  const [payment, setPayment] = useState("Pix");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, [supabase]);

  async function loadData() {
    const [{ data: p }, { data: c }, { data: cash }] = await Promise.all([
      supabase.from("produtos").select("*").order("nome"),
      supabase.from("clientes").select("id,nome").order("nome"),
      supabase.from("caixas").select("*").is("fechado_em", null).order("aberto_em", { ascending: false }).limit(1).maybeSingle()
    ]);
    setProducts((p || []) as Product[]);
    setClients((c || []) as Client[]);
    setCashOpen(cash);
  }

  useEffect(() => { if (session) loadData(); }, [session]);

  async function login(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice("");
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false); if (error) setNotice("Não foi possível entrar: " + error.message);
  }

  async function addProduct(e: React.FormEvent) {
    e.preventDefault(); setNotice("");
    const { error } = await supabase.from("produtos").insert({
      nome: newName.trim(), codigo_barras: newCode.trim() || null,
      preco: Number(newPrice), estoque: Number(newStock), estoque_minimo: 5
    });
    if (error) setNotice("Erro ao cadastrar: " + error.message);
    else { setNotice("Produto cadastrado!"); setNewName(""); setNewCode(""); setNewPrice(""); setNewStock("0"); loadData(); }
  }

  function addToCart(p: Product) {
    setCart(old => {
      const found = old.find(x => x.product.id === p.id);
      if (found) return old.map(x => x.product.id === p.id ? { ...x, quantity: Math.min(x.quantity + 1, p.estoque) } : x);
      return [...old, { product: p, quantity: 1 }];
    });
  }
  const total = cart.reduce((sum, item) => sum + Number(item.product.preco) * item.quantity, 0);
  const filtered = products.filter(p => `${p.nome} ${p.codigo_barras || ""}`.toLowerCase().includes(search.toLowerCase()));

  async function openCash(e: React.FormEvent) {
    e.preventDefault();
    const { data, error } = await supabase.from("caixas").insert({ abertura: Number(opening) }).select().single();
    if (error) setNotice("Erro ao abrir caixa: " + error.message);
    else { setCashOpen(data); setNotice("Caixa aberto!"); }
  }

  async function finishSale() {
    if (!cashOpen) { setNotice("Abra o caixa antes de registrar vendas."); return; }
    if (!cart.length) { setNotice("Adicione produtos à venda."); return; }
    setBusy(true); setNotice("");
    for (const item of cart) {
      if (item.quantity > item.product.estoque) { setNotice(`Estoque insuficiente: ${item.product.nome}`); setBusy(false); return; }
    }
    let clientId: string | null = null;
    if (customerName.trim()) {
      const { data: existing } = await supabase.from("clientes").select("id").ilike("nome", customerName.trim()).limit(1).maybeSingle();
      if (existing) clientId = existing.id;
      else {
        const { data: created, error: ce } = await supabase.from("clientes").insert({ nome: customerName.trim() }).select("id").single();
        if (ce) { setNotice("Erro ao cadastrar cliente: " + ce.message); setBusy(false); return; }
        clientId = created.id;
      }
    }
    const { data: sale, error } = await supabase.from("vendas").insert({ cliente_id: clientId, total, pagamento: payment }).select().single();
    if (error || !sale) { setNotice("Erro ao registrar venda: " + (error?.message || "Tente novamente")); setBusy(false); return; }
    for (const item of cart) {
      const { error: ie } = await supabase.from("itens_venda").insert({ venda_id: sale.id, produto_id: item.product.id, quantidade: item.quantity, preco_unitario: item.product.preco });
      const { error: pe } = await supabase.from("produtos").update({ estoque: item.product.estoque - item.quantity }).eq("id", item.product.id);
      if (ie || pe) setNotice("Venda registrada, mas houve erro ao atualizar um item. Confira o estoque.");
    }
    await supabase.from("movimentos_caixa").insert({ caixa_id: cashOpen.id, tipo: "entrada", valor: total, descricao: `Venda ${sale.id} - ${payment}` });
    setCart([]); setCustomerName(""); setBusy(false); setNotice("Venda registrada com sucesso!"); loadData();
  }

  async function closeCash() {
    if (!cashOpen) return;
    const { error } = await supabase.from("caixas").update({ fechado_em: new Date().toISOString(), fechamento: Number(cashOpen.abertura) }).eq("id", cashOpen.id);
    if (error) setNotice("Erro ao fechar caixa: " + error.message);
    else { setNotice("Caixa fechado."); loadData(); }
  }

  async function logout() { await supabase.auth.signOut(); setCart([]); }

  if (!session) return <main className="loginWrap"><form className="loginCard" onSubmit={login}>
    <div className="brandMark">JC</div><p className="eyebrow">SISTEMA DE VENDAS</p><h1>JC VARIEDADES</h1><p className="muted">Entre para acessar seu PDV</p>
    <label>E-mail<input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></label>
    <label>Senha<input type="password" value={password} onChange={e => setPassword(e.target.value)} required /></label>
    <button className="primary full" disabled={busy}>{busy ? "Entrando..." : "Entrar"}</button>
    {notice && <p className="notice">{notice}</p>}
  </form></main>;

  return <main className="appShell">
    <header className="topbar"><div><div className="brandSmall">JC</div><div><strong>JC VARIEDADES</strong><small>PAINEL DE VENDAS</small></div></div><button className="ghost" onClick={logout}><LogOut size={17}/> Sair</button></header>
    <section className="welcome"><div><p className="eyebrow">BEM-VINDO AO SEU NEGÓCIO</p><h1>Olá! Vamos vender?</h1><p className="muted">Controle suas vendas, produtos e caixa em um só lugar.</p></div><span className={cashOpen ? "status on" : "status"}>{cashOpen ? "Caixa aberto" : "Caixa fechado"}</span></section>
    <nav className="tabs">
      <button className={tab==="vendas"?"active":""} onClick={()=>setTab("vendas")}><ShoppingCart/>Vendas</button>
      <button className={tab==="estoque"?"active":""} onClick={()=>setTab("estoque")}><Boxes/>Estoque</button>
      <button className={tab==="clientes"?"active":""} onClick={()=>setTab("clientes")}><Users/>Clientes</button>
      <button className={tab==="caixa"?"active":""} onClick={()=>setTab("caixa")}><Wallet/>Caixa</button>
      <button className={tab==="relatorios"?"active":""} onClick={()=>setTab("relatorios")}><BarChart3/>Relatórios</button>
    </nav>
    {notice && <div className="noticeBar">{notice}<button onClick={()=>setNotice("")}>×</button></div>}
    {tab==="vendas" && <section className="contentGrid"><div className="panel"><div className="panelHead"><div><h2>Produtos</h2><p className="muted">Busque pelo nome ou código de barras</p></div></div><div className="search"><Search size={18}/><input placeholder="Buscar produto..." value={search} onChange={e=>setSearch(e.target.value)} /></div><div className="productGrid">{filtered.map(p=><button className="productTile" key={p.id} onClick={()=>addToCart(p)} disabled={p.estoque<1}><strong>{p.nome}</strong><span>{p.codigo_barras || "Sem código"}</span><b>{money(Number(p.preco))}</b><small>Estoque: {p.estoque}</small></button>)}</div></div>
      <aside className="panel cartPanel"><h2><ShoppingCart size={20}/> Venda atual</h2><label>Cliente (opcional)<input value={customerName} onChange={e=>setCustomerName(e.target.value)} placeholder="Nome do cliente"/></label>{cart.map(item=><div className="cartLine" key={item.product.id}><div><strong>{item.product.nome}</strong><small>{item.quantity} × {money(Number(item.product.preco))}</small></div><div className="qty"><button onClick={()=>setCart(c=>c.map(x=>x.product.id===item.product.id?{...x,quantity:Math.max(1,x.quantity-1)}:x))}>−</button><b>{item.quantity}</b><button onClick={()=>setCart(c=>c.map(x=>x.product.id===item.product.id?{...x,quantity:Math.min(item.product.estoque,x.quantity+1)}:x))}>+</button><button onClick={()=>setCart(c=>c.filter(x=>x.product.id!==item.product.id))}>×</button></div></div>)}<label>Pagamento<select value={payment} onChange={e=>setPayment(e.target.value)}><option>Pix</option><option>Dinheiro</option><option>Cartão de débito</option><option>Cartão de crédito</option></select></label><div className="total"><span>Total</span><strong>{money(total)}</strong></div><button className="primary full" onClick={finishSale} disabled={busy}>{busy?"Registrando...":"Finalizar venda"}</button></aside></section>}
    {tab==="estoque" && <section className="panel"><div className="panelHead"><div><h2><Boxes/> Estoque de produtos</h2><p className="muted">Cadastre e acompanhe seus produtos.</p></div></div><form className="formGrid" onSubmit={addProduct}><label>Nome do produto<input value={newName} onChange={e=>setNewName(e.target.value)} required/></label><label>Código de barras<input value={newCode} onChange={e=>setNewCode(e.target.value)}/></label><label>Preço de venda (R$)<input type="number" step="0.01" min="0" value={newPrice} onChange={e=>setNewPrice(e.target.value)} required/></label><label>Estoque inicial<input type="number" min="0" value={newStock} onChange={e=>setNewStock(e.target.value)} required/></label><button className="primary"><PackagePlus size={17}/> Cadastrar produto</button></form><div className="tableWrap"><table><thead><tr><th>Produto</th><th>Código</th><th>Preço</th><th>Estoque</th><th>Status</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td>{p.nome}</td><td>{p.codigo_barras || "—"}</td><td>{money(Number(p.preco))}</td><td>{p.estoque}</td><td><span className={p.estoque<=p.estoque_minimo?"low":"good"}>{p.estoque<=p.estoque_minimo?"Estoque baixo":"Normal"}</span></td></tr>)}</tbody></table></div></section>}
    {tab==="clientes" && <section className="panel"><h2><Users/> Clientes cadastrados</h2><p className="muted">Clientes são cadastrados automaticamente quando informados em uma venda.</p>{clients.map(c=><div className="simpleRow" key={c.id}>{c.nome}</div>)}{!clients.length&&<p className="muted">Nenhum cliente cadastrado ainda.</p>}</section>}
    {tab==="caixa" && <section className="panel"><h2><Wallet/> Controle de caixa</h2>{cashOpen ? <><p className="muted">Caixa aberto em {new Date(cashOpen.aberto_em).toLocaleString("pt-BR")}</p><p>Valor inicial: <strong>{money(Number(cashOpen.abertura))}</strong></p><button className="danger" onClick={closeCash}>Fechar caixa</button></> : <form className="formGrid" onSubmit={openCash}><label>Valor inicial do caixa (R$)<input type="number" step="0.01" min="0" value={opening} onChange={e=>setOpening(e.target.value)}/></label><button className="primary">Abrir caixa</button></form>}</section>}
    {tab==="relatorios" && <section className="panel"><h2><BarChart3/> Relatórios</h2><p className="muted">Resumo das vendas registradas.</p><p>Produtos cadastrados: <strong>{products.length}</strong></p><p>Clientes cadastrados: <strong>{clients.length}</strong></p><p>Itens com estoque baixo: <strong>{products.filter(p=>p.estoque<=p.estoque_minimo).length}</strong></p><p className="muted">Relatório financeiro detalhado e filtros por período serão adicionados na próxima versão.</p></section>}
    <footer>JC VARIEDADES • Sistema PDV</footer>
  </main>;
}